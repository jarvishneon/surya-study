STUDY MATERIAL – IMPORTANT QUESTION BANK

This folder matches the paths used by the Study Material section in the dashboard.

Competitive:
- English, Reasoning, Math, GS, Hindi (20 Q&A each)

Board:
- 9th class: Hindi, English, Math, Science (20 Q&A each)
- 10th class: Hindi, English, Math, Science (20 Q&A each)

Total: 13 JSON files, 260 question-answer entries.

These are curated high-priority practice questions based on common foundational topics and NCERT-style Class 9–10 coverage. They are not a guarantee of questions appearing in any examination. Please verify chapter-specific coverage against the latest school/board syllabus.
